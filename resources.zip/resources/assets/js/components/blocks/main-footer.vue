<template>
  <footer>
    <div class="footer_image">
      <img src="/image/footer/image1.png" alt />
      <img src="/image/footer/image2.png" alt />
      <img src="/image/footer/image3.png" alt />
      <img src="/image/footer/image4.png" alt />
      <img src="/image/footer/image5.png" alt />
      <img src="/image/footer/image6.png" alt />
    </div>
    <div class="opacity_wrapper"></div>
    <span class="footer_copyright">
      &copy; Copyright
      <span class="date">2019</span>
    </span>
  </footer>
</template>

<script>
export default {
  mounted() {}
};
</script>
