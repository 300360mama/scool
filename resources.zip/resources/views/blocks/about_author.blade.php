@section('about_author')
<div class="author_block">

        <img src="./image/comments/author.png" class="author_icon" alt="Author image">
        <div class="author_info_block">
            <span class="author_name">
                Anna Maria Novak
            </span>
            <span class="author_about">
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, 
            sed diam nonummy nibh euismod tincidunt ut laoreet dolore 
            magna aliquam erat volutpat. Ut wisi enim ad minim veniam, 
            quis nostrud exerci tation ullamcorper 
            suscipit lobortis nisl ut aliquip ex ea commodo consequat
            </span>
        </div>
</div>
@endsection