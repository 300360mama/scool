@section('header')
    <header>

        <nav class="navigation">
            <i class="fas fa-bars"></i>
            <ul>
                <li class="menu"><a href="scool/">Головна</a></li>
                <li class="menu"><a href="/items">Предмети</a></li>
                <li class="menu"><a href="/interesting">Цікавинки</a></li>
                <li class="menu"><a href="/preschooler">Дошкільнятам</a></li>
                <li class="menu"><a href="/games">Розвиваючі ігри</a></li>
            </ul>
        </nav>
        <h1 class="logo_text">SCHOOL</h1>
    </header>
@endsection