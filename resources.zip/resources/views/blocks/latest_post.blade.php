@section('latest_post')

<div class="latest_post">

<a href="#" class="latest_post_article">
    <img src="" alt="latest post Image" class="latest_post_icon">
    <span class="latest_post_title">Article title</span>
    <span class="latest_post_date">10 November 2019</span>
</a>
</div>
@endsection