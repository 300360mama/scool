<?php
/**
 * Created by PhpStorm.
 * User: саня
 * Date: 21.09.2019
 * Time: 22:18
 */


function p($data) {
    echo  "<pre>";

    print_r($data);
    echo  "</pre>";
}


